// เปิด popup เลือกสกินของฮีโร่ (โหมดหลายสกิน)
function openSkinPicker(heroId) {
    const modalEl = document.getElementById("skinPickerModal");
    const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
    const titleEl = document.getElementById("skinPickerTitle");
    const bodyEl = document.getElementById("skinPickerBody");

    bodyEl.innerHTML = '<div class="text-center py-4"><div class="spinner-border text-light" role="status"></div></div>';
    titleEl.textContent = "กำลังโหลด...";
    modal.show();

    fetch(`/api/hero/${heroId}/skins.json`)
        .then((res) => res.json())
        .then((data) => {
            titleEl.textContent = `เลือกสกินของ ${data.hero_name}`;

            if (!data.skins || data.skins.length === 0) {
                bodyEl.innerHTML = '<p class="text-center text-muted mb-0">ยังไม่มีสกินที่พร้อมดาวน์โหลดสำหรับฮีโร่นี้</p>';
                return;
            }

            let html = '<div class="row g-3">';
            data.skins.forEach((skin) => {
                html += `
                    <div class="col-6 col-md-4">
                        <a href="${skin.detail_url}" class="skin-pick-thumb">
                            <img src="${skin.image_url || 'https://via.placeholder.com/300x400?text=No+Image'}" alt="${skin.name}">
                            <div>${skin.name}</div>
                        </a>
                    </div>
                `;
            });
            html += "</div>";
            bodyEl.innerHTML = html;
        })
        .catch(() => {
            bodyEl.innerHTML = '<p class="text-center text-danger mb-0">เกิดข้อผิดพลาดในการโหลดข้อมูล</p>';
        });
}
