from flask import Blueprint, render_template, request, jsonify, abort

from models import Category, Hero, Skin, Pack, Announcement, VideoClip, Background

public_bp = Blueprint("public", __name__)


def get_active_background():
    """คืนค่าพื้นหลังที่ถูกเปิดใช้งานอยู่ (ถ้ามี)"""
    return Background.query.filter_by(is_active=True).first()


def get_active_announcement():
    """คืนค่าประกาศล่าสุดที่เปิดใช้งานอยู่"""
    return (
        Announcement.query.filter_by(is_active=True)
        .order_by(Announcement.created_at.desc())
        .first()
    )


def get_active_videos():
    return VideoClip.query.filter_by(is_active=True).order_by(VideoClip.sort_order.asc()).all()


@public_bp.route("/")
def index():
    background = get_active_background()
    announcement = get_active_announcement()
    videos = get_active_videos()

    categories = Category.query.filter_by(is_active=True).order_by(Category.sort_order.asc()).all()

    # เตรียมข้อมูลแต่ละหมวดให้พร้อมแสดงผล โดยกรองเฉพาะรายการที่เปิดใช้งานและมีลิงก์ดาวน์โหลด
    category_data = []
    for cat in categories:
        if cat.kind == "single":
            skins = [s for s in cat.skins if s.is_visible()]
            skins.sort(key=lambda s: s.sort_order)
            category_data.append({"category": cat, "type": "single", "entries": skins})

        elif cat.kind == "multi":
            # จัดกลุ่มสกินตามฮีโร่ แสดงเฉพาะฮีโร่ที่เปิดใช้งานและมีสกินที่มองเห็นได้อย่างน้อย 1 อัน
            heroes_map = {}
            for s in cat.skins:
                if s.is_visible() and s.hero and s.hero.is_active:
                    heroes_map.setdefault(s.hero, []).append(s)
            hero_groups = []
            for hero, skins in heroes_map.items():
                skins.sort(key=lambda s: s.sort_order)
                hero_groups.append({"hero": hero, "skins": skins})
            hero_groups.sort(key=lambda g: g["hero"].name)
            category_data.append({"category": cat, "type": "multi", "entries": hero_groups})

        elif cat.kind == "pack":
            packs = [p for p in cat.packs if p.is_visible()]
            packs.sort(key=lambda p: p.sort_order)
            category_data.append({"category": cat, "type": "pack", "entries": packs})

    return render_template(
        "index.html",
        background=background,
        announcement=announcement,
        videos=videos,
        category_data=category_data,
    )


@public_bp.route("/category/<int:category_id>")
def category_view(category_id):
    background = get_active_background()
    cat = Category.query.get_or_404(category_id)
    if not cat.is_active:
        abort(404)

    query = request.args.get("q", "").strip()

    if cat.kind == "single":
        skins_q = [s for s in cat.skins if s.is_visible()]
        if query:
            skins_q = [s for s in skins_q if query.lower() in s.name.lower() or (s.hero and query.lower() in s.hero.name.lower())]
        skins_q.sort(key=lambda s: s.sort_order)
        return render_template("category.html", background=background, category=cat, single_items=skins_q)

    elif cat.kind == "multi":
        heroes_map = {}
        for s in cat.skins:
            if s.is_visible() and s.hero and s.hero.is_active:
                if query and query.lower() not in s.hero.name.lower() and query.lower() not in s.name.lower():
                    continue
                heroes_map.setdefault(s.hero, []).append(s)
        hero_groups = []
        for hero, skins in heroes_map.items():
            skins.sort(key=lambda s: s.sort_order)
            hero_groups.append({"hero": hero, "skins": skins})
        hero_groups.sort(key=lambda g: g["hero"].name)
        return render_template("category.html", background=background, category=cat, hero_groups=hero_groups)

    elif cat.kind == "pack":
        packs_q = [p for p in cat.packs if p.is_visible()]
        if query:
            packs_q = [p for p in packs_q if query.lower() in p.name.lower()]
        packs_q.sort(key=lambda p: p.sort_order)
        return render_template("category.html", background=background, category=cat, pack_items=packs_q)

    abort(404)


@public_bp.route("/heroes")
def heroes_page():
    """หน้าแสดงฮีโร่ทั้งหมด"""
    background = get_active_background()
    heroes = (
        Hero.query
        .filter_by(is_active=True)
        .order_by(Hero.name.asc())
        .all()
    )
    # กรองเฉพาะฮีโร่ที่มีสกินที่มองเห็นได้อย่างน้อย 1 ตัว
    heroes = [h for h in heroes if any(s.is_visible() for s in h.skins)]
    return render_template("heroes.html", background=background, heroes=heroes)


@public_bp.route("/hero/<int:hero_id>")
def hero_detail(hero_id):
    """หน้าแสดงสกินทั้งหมดของฮีโร่คนนี้"""
    background = get_active_background()
    hero = Hero.query.get_or_404(hero_id)
    if not hero.is_active:
        abort(404)
    skins = sorted([s for s in hero.skins if s.is_visible()], key=lambda s: s.sort_order)
    return render_template("hero_detail.html", background=background, hero=hero, skins=skins)



@public_bp.route("/api/hero/<int:hero_id>/skins.json")
def api_hero_skins(hero_id):
    """คืนรายการสกินของฮีโร่ (ใช้แสดงใน popup เลือกสกิน)"""
    hero = Hero.query.get_or_404(hero_id)
    skins = [s for s in hero.skins if s.is_visible()]
    skins.sort(key=lambda s: s.sort_order)
    data = {
        "hero_name": hero.name,
        "skins": [
            {
                "id": s.id,
                "name": s.name,
                "image_url": s.image_url,
                "detail_url": f"/skin/{s.id}",
            }
            for s in skins
        ],
    }
    return jsonify(data)


@public_bp.route("/skin/<int:skin_id>")
def skin_detail(skin_id):
    """หน้ารายละเอียดก่อนดาวน์โหลดสำหรับสกิน"""
    background = get_active_background()
    skin = Skin.query.get_or_404(skin_id)
    if not skin.is_visible():
        abort(404)
    return render_template("detail.html", background=background, item=skin, item_type="skin")


@public_bp.route("/pack/<int:pack_id>")
def pack_detail(pack_id):
    """หน้ารายละเอียดก่อนดาวน์โหลดสำหรับแพ็ค"""
    background = get_active_background()
    pack = Pack.query.get_or_404(pack_id)
    if not pack.is_visible():
        abort(404)
    return render_template("detail.html", background=background, item=pack, item_type="pack")


@public_bp.route("/search")
def search():
    background = get_active_background()
    query = request.args.get("q", "").strip()

    hero_results = []
    skin_results = []

    if query:
        heroes = Hero.query.filter(Hero.is_active == True, Hero.name.ilike(f"%{query}%")).all()
        for hero in heroes:
            visible_skins = [s for s in hero.skins if s.is_visible()]
            if visible_skins:
                hero_results.append({"hero": hero, "skins": visible_skins})

        skins = Skin.query.filter(Skin.is_active == True, Skin.name.ilike(f"%{query}%")).all()
        skin_results = [s for s in skins if s.is_visible()]

    return render_template(
        "search.html",
        background=background,
        query=query,
        hero_results=hero_results,
        skin_results=skin_results,
    )
