import os
import re
import uuid
from functools import wraps
from flask import Blueprint, render_template, request, redirect, url_for, session, flash, current_app
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename


def to_youtube_embed(url: str) -> str:
    """
    แปลง YouTube URL ทุกรูปแบบให้เป็น embed URL สำหรับ iframe
    รองรับ:
      - https://youtu.be/VIDEO_ID
      - https://www.youtube.com/watch?v=VIDEO_ID
      - https://www.youtube.com/shorts/VIDEO_ID
      - https://www.youtube.com/embed/VIDEO_ID  (ไม่แปลง)
    """
    url = url.strip()

    # ถ้าเป็น embed URL อยู่แล้ว → คืนค่าเดิม
    if re.search(r'youtube\.com/embed/', url):
        return url

    # youtu.be/VIDEO_ID
    m = re.search(r'youtu\.be/([A-Za-z0-9_\-]{11})', url)
    if m:
        return f'https://www.youtube.com/embed/{m.group(1)}'

    # youtube.com/shorts/VIDEO_ID
    m = re.search(r'youtube\.com/shorts/([A-Za-z0-9_\-]{11})', url)
    if m:
        return f'https://www.youtube.com/embed/{m.group(1)}'

    # youtube.com/watch?v=VIDEO_ID
    m = re.search(r'[?&]v=([A-Za-z0-9_\-]{11})', url)
    if m:
        return f'https://www.youtube.com/embed/{m.group(1)}'

    # ลิงก์ที่ไม่รู้จัก → คืนค่าเดิม (ให้ผู้ใช้แก้เอง)
    return url

from extensions import db
from models import Admin, Category, Hero, Skin, Pack, PackItem, Announcement, VideoClip, Background, SocialLink, MenuLink

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


def login_required(view_func):
    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if not session.get("admin_id"):
            flash("กรุณาเข้าสู่ระบบก่อนใช้งาน", "warning")
            return redirect(url_for("auth.login"))
        return view_func(*args, **kwargs)
    return wrapped


def _is_allowed_image(filename):
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in current_app.config["ALLOWED_IMAGE_EXTENSIONS"]
    )


def save_uploaded_image(file_field_name):
    """
    บันทึกไฟล์รูปภาพที่อัปโหลดจากเครื่อง (ถ้ามี) ลงในโฟลเดอร์ static/uploads
    คืนค่าเป็น URL แบบ /static/uploads/xxxx.jpg ถ้าอัปโหลดสำเร็จ
    คืนค่า None ถ้าไม่มีไฟล์แนบมา หรือไฟล์ไม่ถูกต้อง
    """
    file = request.files.get(file_field_name)
    if not file or file.filename == "":
        return None

    if not _is_allowed_image(file.filename):
        flash("รองรับเฉพาะไฟล์รูปภาพ (png, jpg, jpeg, gif, webp) เท่านั้น", "danger")
        return None

    ext = file.filename.rsplit(".", 1)[1].lower()
    safe_name = f"{uuid.uuid4().hex}.{ext}"
    save_path = os.path.join(current_app.config["UPLOAD_FOLDER"], safe_name)
    file.save(save_path)

    return url_for("static", filename=f"uploads/{safe_name}")


def resolve_image_url(file_field_name, url_field_name, existing_url=None):
    """
    ตัดสินใจว่าจะใช้รูปจากไฟล์ที่อัปโหลด หรือจากลิงก์ URL ที่กรอกไว้
    ลำดับความสำคัญ: ไฟล์ที่อัปโหลดใหม่ > ลิงก์ URL ที่กรอก > รูปเดิม (ตอนแก้ไข)
    """
    uploaded_url = save_uploaded_image(file_field_name)
    if uploaded_url:
        return uploaded_url

    typed_url = request.form.get(url_field_name, "").strip()
    if typed_url:
        return typed_url

    return existing_url


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------

@admin_bp.route("/")
@login_required
def dashboard():
    stats = {
        "hero_count": Hero.query.count(),
        "skin_count": Skin.query.count(),
        "pack_count": Pack.query.count(),
        "category_count": Category.query.count(),
        "announcement_count": Announcement.query.count(),
        "video_count": VideoClip.query.count(),
        "background_count": Background.query.count(),
    }
    return render_template("admin/dashboard.html", stats=stats)


# ---------------------------------------------------------------------------
# Categories
# ---------------------------------------------------------------------------

@admin_bp.route("/categories")
@login_required
def categories_list():
    categories = Category.query.order_by(Category.sort_order.asc()).all()
    return render_template("admin/categories.html", categories=categories)


@admin_bp.route("/categories/new", methods=["GET", "POST"])
@login_required
def category_new():
    if request.method == "POST":
        cat = Category(
            name=request.form.get("name", "").strip(),
            kind=request.form.get("kind"),
            description=request.form.get("description", "").strip(),
            sort_order=int(request.form.get("sort_order") or 0),
            is_active=bool(request.form.get("is_active")),
        )
        db.session.add(cat)
        db.session.commit()
        flash("เพิ่มหมวดหมู่เรียบร้อยแล้ว", "success")
        return redirect(url_for("admin.categories_list"))
    return render_template("admin/category_form.html", category=None)


@admin_bp.route("/categories/<int:category_id>/edit", methods=["GET", "POST"])
@login_required
def category_edit(category_id):
    cat = Category.query.get_or_404(category_id)
    if request.method == "POST":
        cat.name = request.form.get("name", "").strip()
        cat.kind = request.form.get("kind")
        cat.description = request.form.get("description", "").strip()
        cat.sort_order = int(request.form.get("sort_order") or 0)
        cat.is_active = bool(request.form.get("is_active"))
        db.session.commit()
        flash("แก้ไขหมวดหมู่เรียบร้อยแล้ว", "success")
        return redirect(url_for("admin.categories_list"))
    return render_template("admin/category_form.html", category=cat)


@admin_bp.route("/categories/<int:category_id>/delete", methods=["POST"])
@login_required
def category_delete(category_id):
    cat = Category.query.get_or_404(category_id)
    db.session.delete(cat)
    db.session.commit()
    flash("ลบหมวดหมู่เรียบร้อยแล้ว", "info")
    return redirect(url_for("admin.categories_list"))


@admin_bp.route("/categories/<int:category_id>/toggle", methods=["POST"])
@login_required
def category_toggle(category_id):
    cat = Category.query.get_or_404(category_id)
    cat.is_active = not cat.is_active
    db.session.commit()
    return redirect(url_for("admin.categories_list"))


# ---------------------------------------------------------------------------
# Heroes
# ---------------------------------------------------------------------------

@admin_bp.route("/heroes")
@login_required
def heroes_list():
    query = request.args.get("q", "").strip()
    heroes_q = Hero.query
    if query:
        heroes_q = heroes_q.filter(Hero.name.ilike(f"%{query}%"))
    heroes = heroes_q.order_by(Hero.name.asc()).all()
    return render_template("admin/heroes.html", heroes=heroes, query=query)


@admin_bp.route("/heroes/new", methods=["GET", "POST"])
@login_required
def hero_new():
    if request.method == "POST":
        hero = Hero(
            name=request.form.get("name", "").strip(),
            image_url=resolve_image_url("image_file", "image_url"),
            is_active=bool(request.form.get("is_active")),
        )
        db.session.add(hero)
        db.session.commit()
        flash("เพิ่มฮีโร่เรียบร้อยแล้ว", "success")
        return redirect(url_for("admin.heroes_list"))
    return render_template("admin/hero_form.html", hero=None)


@admin_bp.route("/heroes/<int:hero_id>/edit", methods=["GET", "POST"])
@login_required
def hero_edit(hero_id):
    hero = Hero.query.get_or_404(hero_id)
    if request.method == "POST":
        hero.name = request.form.get("name", "").strip()
        hero.image_url = resolve_image_url("image_file", "image_url", existing_url=hero.image_url)
        hero.is_active = bool(request.form.get("is_active"))
        db.session.commit()
        flash("แก้ไขฮีโร่เรียบร้อยแล้ว", "success")
        return redirect(url_for("admin.heroes_list"))
    return render_template("admin/hero_form.html", hero=hero)


@admin_bp.route("/heroes/<int:hero_id>/delete", methods=["POST"])
@login_required
def hero_delete(hero_id):
    hero = Hero.query.get_or_404(hero_id)
    db.session.delete(hero)
    db.session.commit()
    flash("ลบฮีโร่เรียบร้อยแล้ว (สกินที่เกี่ยวข้องจะถูกลบด้วย)", "info")
    return redirect(url_for("admin.heroes_list"))


@admin_bp.route("/heroes/<int:hero_id>/toggle", methods=["POST"])
@login_required
def hero_toggle(hero_id):
    hero = Hero.query.get_or_404(hero_id)
    hero.is_active = not hero.is_active
    db.session.commit()
    return redirect(url_for("admin.heroes_list"))


# ---------------------------------------------------------------------------
# Skins
# ---------------------------------------------------------------------------

@admin_bp.route("/skins")
@login_required
def skins_list():
    query = request.args.get("q", "").strip()
    skins_q = Skin.query
    if query:
        skins_q = skins_q.filter(Skin.name.ilike(f"%{query}%"))
    skins = skins_q.order_by(Skin.id.desc()).all()
    return render_template("admin/skins.html", skins=skins, query=query)


@admin_bp.route("/skins/new", methods=["GET", "POST"])
@login_required
def skin_new():
    heroes = Hero.query.order_by(Hero.name.asc()).all()
    categories = Category.query.filter(Category.kind.in_(["single", "multi"])).order_by(Category.sort_order.asc()).all()

    if request.method == "POST":
        skin = Skin(
            hero_id=int(request.form.get("hero_id")),
            category_id=int(request.form.get("category_id")),
            name=request.form.get("name", "").strip(),
            image_url=resolve_image_url("image_file", "image_url"),
            download_url=request.form.get("download_url", "").strip(),
            description=request.form.get("description", "").strip(),
            sort_order=int(request.form.get("sort_order") or 0),
            is_active=bool(request.form.get("is_active")),
        )
        db.session.add(skin)
        db.session.commit()
        flash("เพิ่มสกินเรียบร้อยแล้ว", "success")
        return redirect(url_for("admin.skins_list"))

    return render_template("admin/skin_form.html", skin=None, heroes=heroes, categories=categories)


@admin_bp.route("/skins/<int:skin_id>/edit", methods=["GET", "POST"])
@login_required
def skin_edit(skin_id):
    skin = Skin.query.get_or_404(skin_id)
    heroes = Hero.query.order_by(Hero.name.asc()).all()
    categories = Category.query.filter(Category.kind.in_(["single", "multi"])).order_by(Category.sort_order.asc()).all()

    if request.method == "POST":
        skin.hero_id = int(request.form.get("hero_id"))
        skin.category_id = int(request.form.get("category_id"))
        skin.name = request.form.get("name", "").strip()
        skin.image_url = resolve_image_url("image_file", "image_url", existing_url=skin.image_url)
        skin.download_url = request.form.get("download_url", "").strip()
        skin.description = request.form.get("description", "").strip()
        skin.sort_order = int(request.form.get("sort_order") or 0)
        skin.is_active = bool(request.form.get("is_active"))
        db.session.commit()
        flash("แก้ไขสกินเรียบร้อยแล้ว", "success")
        return redirect(url_for("admin.skins_list"))

    return render_template("admin/skin_form.html", skin=skin, heroes=heroes, categories=categories)


@admin_bp.route("/skins/<int:skin_id>/delete", methods=["POST"])
@login_required
def skin_delete(skin_id):
    skin = Skin.query.get_or_404(skin_id)
    db.session.delete(skin)
    db.session.commit()
    flash("ลบสกินเรียบร้อยแล้ว", "info")
    return redirect(url_for("admin.skins_list"))


@admin_bp.route("/skins/<int:skin_id>/toggle", methods=["POST"])
@login_required
def skin_toggle(skin_id):
    skin = Skin.query.get_or_404(skin_id)
    skin.is_active = not skin.is_active
    db.session.commit()
    return redirect(url_for("admin.skins_list"))


# ---------------------------------------------------------------------------
# Packs
# ---------------------------------------------------------------------------

@admin_bp.route("/packs")
@login_required
def packs_list():
    packs = Pack.query.order_by(Pack.id.desc()).all()
    return render_template("admin/packs.html", packs=packs)


@admin_bp.route("/packs/new", methods=["GET", "POST"])
@login_required
def pack_new():
    categories = Category.query.filter_by(kind="pack").order_by(Category.sort_order.asc()).all()
    if request.method == "POST":
        pack = Pack(
            category_id=int(request.form.get("category_id")),
            name=request.form.get("name", "").strip(),
            image_url=resolve_image_url("image_file", "image_url"),
            download_url=request.form.get("download_url", "").strip(),
            description=request.form.get("description", "").strip(),
            sort_order=int(request.form.get("sort_order") or 0),
            is_active=bool(request.form.get("is_active")),
        )
        db.session.add(pack)
        db.session.commit()
        flash("เพิ่มแพ็คเรียบร้อยแล้ว", "success")
        return redirect(url_for("admin.pack_edit", pack_id=pack.id))
    return render_template("admin/pack_form.html", pack=None, categories=categories)


@admin_bp.route("/packs/<int:pack_id>/edit", methods=["GET", "POST"])
@login_required
def pack_edit(pack_id):
    pack = Pack.query.get_or_404(pack_id)
    categories = Category.query.filter_by(kind="pack").order_by(Category.sort_order.asc()).all()

    if request.method == "POST":
        pack.category_id = int(request.form.get("category_id"))
        pack.name = request.form.get("name", "").strip()
        pack.image_url = resolve_image_url("image_file", "image_url", existing_url=pack.image_url)
        pack.download_url = request.form.get("download_url", "").strip()
        pack.description = request.form.get("description", "").strip()
        pack.sort_order = int(request.form.get("sort_order") or 0)
        pack.is_active = bool(request.form.get("is_active"))
        db.session.commit()
        flash("แก้ไขแพ็คเรียบร้อยแล้ว", "success")
        return redirect(url_for("admin.pack_edit", pack_id=pack.id))

    return render_template("admin/pack_form.html", pack=pack, categories=categories)


@admin_bp.route("/packs/<int:pack_id>/delete", methods=["POST"])
@login_required
def pack_delete(pack_id):
    pack = Pack.query.get_or_404(pack_id)
    db.session.delete(pack)
    db.session.commit()
    flash("ลบแพ็คเรียบร้อยแล้ว", "info")
    return redirect(url_for("admin.packs_list"))


@admin_bp.route("/packs/<int:pack_id>/toggle", methods=["POST"])
@login_required
def pack_toggle(pack_id):
    pack = Pack.query.get_or_404(pack_id)
    pack.is_active = not pack.is_active
    db.session.commit()
    return redirect(url_for("admin.packs_list"))


@admin_bp.route("/packs/<int:pack_id>/items/add", methods=["POST"])
@login_required
def pack_item_add(pack_id):
    pack = Pack.query.get_or_404(pack_id)
    label = request.form.get("label", "").strip()
    if label:
        db.session.add(PackItem(pack_id=pack.id, label=label))
        db.session.commit()
        flash("เพิ่มรายการสกินในแพ็คแล้ว", "success")
    return redirect(url_for("admin.pack_edit", pack_id=pack.id))


@admin_bp.route("/packs/items/<int:item_id>/delete", methods=["POST"])
@login_required
def pack_item_delete(item_id):
    item = PackItem.query.get_or_404(item_id)
    pack_id = item.pack_id
    db.session.delete(item)
    db.session.commit()
    return redirect(url_for("admin.pack_edit", pack_id=pack_id))


# ---------------------------------------------------------------------------
# Announcements
# ---------------------------------------------------------------------------

@admin_bp.route("/announcements")
@login_required
def announcements_list():
    announcements = Announcement.query.order_by(Announcement.created_at.desc()).all()
    return render_template("admin/announcements.html", announcements=announcements)


@admin_bp.route("/announcements/new", methods=["GET", "POST"])
@login_required
def announcement_new():
    if request.method == "POST":
        a = Announcement(
            title=request.form.get("title", "").strip(),
            content=request.form.get("content", "").strip(),
            is_active=bool(request.form.get("is_active")),
        )
        db.session.add(a)
        db.session.commit()
        flash("เพิ่มประกาศเรียบร้อยแล้ว", "success")
        return redirect(url_for("admin.announcements_list"))
    return render_template("admin/announcement_form.html", announcement=None)


@admin_bp.route("/announcements/<int:announcement_id>/edit", methods=["GET", "POST"])
@login_required
def announcement_edit(announcement_id):
    a = Announcement.query.get_or_404(announcement_id)
    if request.method == "POST":
        a.title = request.form.get("title", "").strip()
        a.content = request.form.get("content", "").strip()
        a.is_active = bool(request.form.get("is_active"))
        db.session.commit()
        flash("แก้ไขประกาศเรียบร้อยแล้ว", "success")
        return redirect(url_for("admin.announcements_list"))
    return render_template("admin/announcement_form.html", announcement=a)


@admin_bp.route("/announcements/<int:announcement_id>/delete", methods=["POST"])
@login_required
def announcement_delete(announcement_id):
    a = Announcement.query.get_or_404(announcement_id)
    db.session.delete(a)
    db.session.commit()
    flash("ลบประกาศเรียบร้อยแล้ว", "info")
    return redirect(url_for("admin.announcements_list"))


@admin_bp.route("/announcements/<int:announcement_id>/toggle", methods=["POST"])
@login_required
def announcement_toggle(announcement_id):
    a = Announcement.query.get_or_404(announcement_id)
    a.is_active = not a.is_active
    db.session.commit()
    return redirect(url_for("admin.announcements_list"))


# ---------------------------------------------------------------------------
# Video clips
# ---------------------------------------------------------------------------

@admin_bp.route("/videos")
@login_required
def videos_list():
    videos = VideoClip.query.order_by(VideoClip.sort_order.asc()).all()
    return render_template("admin/videos.html", videos=videos)


@admin_bp.route("/videos/new", methods=["GET", "POST"])
@login_required
def video_new():
    if request.method == "POST":
        v = VideoClip(
            title=request.form.get("title", "").strip(),
            video_url=to_youtube_embed(request.form.get("video_url", "").strip()),
            sort_order=int(request.form.get("sort_order") or 0),
            is_active=bool(request.form.get("is_active")),
        )
        db.session.add(v)
        db.session.commit()
        flash("เพิ่มคลิปเรียบร้อยแล้ว", "success")
        return redirect(url_for("admin.videos_list"))
    return render_template("admin/video_form.html", video=None)


@admin_bp.route("/videos/<int:video_id>/edit", methods=["GET", "POST"])
@login_required
def video_edit(video_id):
    v = VideoClip.query.get_or_404(video_id)
    if request.method == "POST":
        v.title = request.form.get("title", "").strip()
        v.video_url = to_youtube_embed(request.form.get("video_url", "").strip())
        v.sort_order = int(request.form.get("sort_order") or 0)
        v.is_active = bool(request.form.get("is_active"))
        db.session.commit()
        flash("แก้ไขคลิปเรียบร้อยแล้ว", "success")
        return redirect(url_for("admin.videos_list"))
    return render_template("admin/video_form.html", video=v)


@admin_bp.route("/videos/<int:video_id>/delete", methods=["POST"])
@login_required
def video_delete(video_id):
    v = VideoClip.query.get_or_404(video_id)
    db.session.delete(v)
    db.session.commit()
    flash("ลบคลิปเรียบร้อยแล้ว", "info")
    return redirect(url_for("admin.videos_list"))


@admin_bp.route("/videos/<int:video_id>/toggle", methods=["POST"])
@login_required
def video_toggle(video_id):
    v = VideoClip.query.get_or_404(video_id)
    v.is_active = not v.is_active
    db.session.commit()
    return redirect(url_for("admin.videos_list"))


# ---------------------------------------------------------------------------
# Background
# ---------------------------------------------------------------------------

@admin_bp.route("/backgrounds")
@login_required
def backgrounds_list():
    backgrounds = Background.query.order_by(Background.created_at.desc()).all()
    return render_template("admin/background.html", backgrounds=backgrounds)


@admin_bp.route("/backgrounds/new", methods=["GET", "POST"])
@login_required
def background_new():
    if request.method == "POST":
        image_url = resolve_image_url("image_file", "image_url")
        if not image_url:
            flash("กรุณาอัปโหลดรูปภาพจากเครื่อง หรือกรอกลิงก์รูปภาพ", "danger")
            return render_template("admin/background_form.html", background=None)

        bg = Background(
            name=request.form.get("name", "").strip(),
            image_url=image_url,
        )
        db.session.add(bg)
        db.session.commit()

        # ถ้าติ๊กให้ใช้งานทันที ให้ปิดพื้นหลังอื่นทั้งหมดก่อน
        if request.form.get("is_active"):
            Background.query.filter(Background.id != bg.id).update({Background.is_active: False})
            bg.is_active = True
            db.session.commit()

        flash("เพิ่มพื้นหลังเรียบร้อยแล้ว", "success")
        return redirect(url_for("admin.backgrounds_list"))
    return render_template("admin/background_form.html", background=None)


@admin_bp.route("/backgrounds/<int:background_id>/edit", methods=["GET", "POST"])
@login_required
def background_edit(background_id):
    bg = Background.query.get_or_404(background_id)
    if request.method == "POST":
        bg.name = request.form.get("name", "").strip()
        bg.image_url = resolve_image_url("image_file", "image_url", existing_url=bg.image_url)
        db.session.commit()
        flash("แก้ไขพื้นหลังเรียบร้อยแล้ว", "success")
        return redirect(url_for("admin.backgrounds_list"))
    return render_template("admin/background_form.html", background=bg)


@admin_bp.route("/backgrounds/<int:background_id>/delete", methods=["POST"])
@login_required
def background_delete(background_id):
    bg = Background.query.get_or_404(background_id)
    db.session.delete(bg)
    db.session.commit()
    flash("ลบพื้นหลังเรียบร้อยแล้ว", "info")
    return redirect(url_for("admin.backgrounds_list"))


@admin_bp.route("/backgrounds/<int:background_id>/activate", methods=["POST"])
@login_required
def background_activate(background_id):
    """ตั้งพื้นหลังนี้เป็นพื้นหลังที่ใช้งานอยู่ (ปิดพื้นหลังอื่นทั้งหมด)"""
    bg = Background.query.get_or_404(background_id)
    Background.query.update({Background.is_active: False})
    bg.is_active = True
    db.session.commit()
    flash(f"ตั้งค่าพื้นหลัง '{bg.name or bg.id}' เป็นพื้นหลังหลักแล้ว", "success")
    return redirect(url_for("admin.backgrounds_list"))


# ---------------------------------------------------------------------------
# Change admin password
# ---------------------------------------------------------------------------

@admin_bp.route("/change-password", methods=["GET", "POST"])
@login_required
def change_password():
    if request.method == "POST":
        current_password = request.form.get("current_password", "")
        new_password = request.form.get("new_password", "")
        confirm_password = request.form.get("confirm_password", "")

        admin = Admin.query.get(session["admin_id"])

        if not check_password_hash(admin.password_hash, current_password):
            flash("รหัสผ่านปัจจุบันไม่ถูกต้อง", "danger")
        elif len(new_password) < 6:
            flash("รหัสผ่านใหม่ต้องมีความยาวอย่างน้อย 6 ตัวอักษร", "danger")
        elif new_password != confirm_password:
            flash("รหัสผ่านใหม่และการยืนยันไม่ตรงกัน", "danger")
        else:
            admin.password_hash = generate_password_hash(new_password)
            db.session.commit()
            flash("เปลี่ยนรหัสผ่านเรียบร้อยแล้ว", "success")
            return redirect(url_for("admin.dashboard"))

    return render_template("admin/change_password.html")


# ---------------------------------------------------------------------------
# Social Links
# ---------------------------------------------------------------------------

@admin_bp.route("/social-links")
@login_required
def social_links_list():
    links = SocialLink.query.order_by(SocialLink.sort_order.asc()).all()
    return render_template("admin/social_links.html", links=links)


@admin_bp.route("/social-links/new", methods=["GET", "POST"])
@login_required
def social_link_new():
    if request.method == "POST":
        link = SocialLink(
            name=request.form.get("name", "").strip(),
            icon=request.form.get("icon", "").strip(),
            url=request.form.get("url", "").strip(),
            color=request.form.get("color", "#ffffff").strip(),
            sort_order=int(request.form.get("sort_order") or 0),
            is_active=bool(request.form.get("is_active")),
        )
        db.session.add(link)
        db.session.commit()
        flash("เพิ่มลิงก์โซเชียลเรียบร้อยแล้ว", "success")
        return redirect(url_for("admin.social_links_list"))
    return render_template("admin/social_link_form.html", link=None)


@admin_bp.route("/social-links/<int:link_id>/edit", methods=["GET", "POST"])
@login_required
def social_link_edit(link_id):
    link = SocialLink.query.get_or_404(link_id)
    if request.method == "POST":
        link.name     = request.form.get("name", "").strip()
        link.icon     = request.form.get("icon", "").strip()
        link.url      = request.form.get("url", "").strip()
        link.color    = request.form.get("color", "#ffffff").strip()
        link.sort_order = int(request.form.get("sort_order") or 0)
        link.is_active  = bool(request.form.get("is_active"))
        db.session.commit()
        flash("แก้ไขลิงก์โซเชียลเรียบร้อยแล้ว", "success")
        return redirect(url_for("admin.social_links_list"))
    return render_template("admin/social_link_form.html", link=link)


@admin_bp.route("/social-links/<int:link_id>/delete", methods=["POST"])
@login_required
def social_link_delete(link_id):
    link = SocialLink.query.get_or_404(link_id)
    db.session.delete(link)
    db.session.commit()
    flash("ลบลิงก์โซเชียลเรียบร้อยแล้ว", "info")
    return redirect(url_for("admin.social_links_list"))


@admin_bp.route("/social-links/<int:link_id>/toggle", methods=["POST"])
@login_required
def social_link_toggle(link_id):
    link = SocialLink.query.get_or_404(link_id)
    link.is_active = not link.is_active
    db.session.commit()
    return redirect(url_for("admin.social_links_list"))


# ---------------------------------------------------------------------------
# Menu Links (ลิงก์นำทางในเมนูหลัก)
# ---------------------------------------------------------------------------

@admin_bp.route("/menu-links")
@login_required
def menu_links_list():
    links = MenuLink.query.order_by(MenuLink.sort_order.asc()).all()
    return render_template("admin/menu_links.html", links=links)


@admin_bp.route("/menu-links/new", methods=["GET", "POST"])
@login_required
def menu_link_new():
    if request.method == "POST":
        link = MenuLink(
            name=request.form.get("name", "").strip(),
            icon=request.form.get("icon", "fa-solid fa-link").strip(),
            url=request.form.get("url", "").strip(),
            open_new_tab=bool(request.form.get("open_new_tab")),
            sort_order=int(request.form.get("sort_order") or 0),
            is_active=bool(request.form.get("is_active")),
        )
        db.session.add(link)
        db.session.commit()
        flash("เพิ่มลิงก์เมนูเรียบร้อยแล้ว", "success")
        return redirect(url_for("admin.menu_links_list"))
    return render_template("admin/menu_link_form.html", link=None)


@admin_bp.route("/menu-links/<int:link_id>/edit", methods=["GET", "POST"])
@login_required
def menu_link_edit(link_id):
    link = MenuLink.query.get_or_404(link_id)
    if request.method == "POST":
        link.name         = request.form.get("name", "").strip()
        link.icon         = request.form.get("icon", "fa-solid fa-link").strip()
        link.url          = request.form.get("url", "").strip()
        link.open_new_tab = bool(request.form.get("open_new_tab"))
        link.sort_order   = int(request.form.get("sort_order") or 0)
        link.is_active    = bool(request.form.get("is_active"))
        db.session.commit()
        flash("แก้ไขลิงก์เมนูเรียบร้อยแล้ว", "success")
        return redirect(url_for("admin.menu_links_list"))
    return render_template("admin/menu_link_form.html", link=link)


@admin_bp.route("/menu-links/<int:link_id>/delete", methods=["POST"])
@login_required
def menu_link_delete(link_id):
    link = MenuLink.query.get_or_404(link_id)
    db.session.delete(link)
    db.session.commit()
    flash("ลบลิงก์เมนูเรียบร้อยแล้ว", "info")
    return redirect(url_for("admin.menu_links_list"))


@admin_bp.route("/menu-links/<int:link_id>/toggle", methods=["POST"])
@login_required
def menu_link_toggle(link_id):
    link = MenuLink.query.get_or_404(link_id)
    link.is_active = not link.is_active
    db.session.commit()
    return redirect(url_for("admin.menu_links_list"))
