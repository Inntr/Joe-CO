#!/usr/bin/env python3
"""
สร้างเว็บแบบ static (HTML ล้วน) จากไฟล์ข้อมูลในโฟลเดอร์ content/ เพื่อใช้บน Netlify

Netlify จะรันสคริปต์นี้เองทุกครั้งที่มีการแก้ข้อมูล (ผ่านหน้า /admin หรือ push ขึ้น GitHub)
ทดสอบในเครื่องได้ด้วย:   python build_static.py   -> ผลลัพธ์อยู่ใน dist/

ต้องการแค่ Jinja2 (pip install jinja2) ไม่ต้องใช้ Flask
"""
import glob
import json
import os
import shutil
from types import SimpleNamespace
from urllib.parse import quote

from jinja2 import Environment, FileSystemLoader, select_autoescape

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
CONTENT = os.path.join(BASE_DIR, "content")
DIST = os.path.join(BASE_DIR, "dist")


# ---------------------------------------------------------------- อ่านข้อมูล
class Obj(SimpleNamespace):
    """object ธรรมดาที่เข้าถึงฟิลด์แบบ obj.field ได้ (ให้ template ใช้ได้เหมือนเดิม)"""

    def is_visible(self):
        return bool(self.is_active and self.download_url and self.download_url.strip())


def read_folder(name):
    """อ่านไฟล์ .json ทั้งหมดใน content/<name>/ — ชื่อไฟล์ (ไม่รวมนามสกุล) คือ id"""
    items = []
    for path in sorted(glob.glob(os.path.join(CONTENT, name, "*.json"))):
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
        except ValueError as e:
            raise SystemExit(f"อ่านไฟล์ข้อมูลไม่ได้: {path}\n{e}")
        data["id"] = os.path.splitext(os.path.basename(path))[0]
        items.append(data)
    return items


def flag(d, key, default=True):
    v = d.get(key, default)
    return default if v is None else bool(v)


def num(d, key):
    try:
        return int(d.get(key) or 0)
    except (TypeError, ValueError):
        return 0


def text(d, key, default=""):
    v = d.get(key)
    return default if v is None else str(v)


def load_data():
    if not os.path.isdir(CONTENT):
        raise SystemExit(f"ไม่พบโฟลเดอร์ข้อมูล: {CONTENT}")

    heroes = {d["id"]: Obj(id=d["id"], name=text(d, "name"), image_url=text(d, "image_url"),
                           is_active=flag(d, "is_active"), skins=[])
              for d in read_folder("heroes")}
    cats = {d["id"]: Obj(id=d["id"], name=text(d, "name"), kind=text(d, "kind"),
                         description=text(d, "description"), is_active=flag(d, "is_active"),
                         sort_order=num(d, "sort_order"), skins=[], packs=[])
            for d in read_folder("categories")}

    skins = []
    for d in read_folder("skins"):
        s = Obj(id=d["id"], name=text(d, "name"), image_url=text(d, "image_url"),
                download_url=text(d, "download_url"), description=text(d, "description"),
                is_active=flag(d, "is_active"), sort_order=num(d, "sort_order"),
                hero=heroes.get(text(d, "hero")), category=cats.get(text(d, "category")))
        if not s.hero or not s.category:
            print(f"⚠️  ข้ามสกิน '{s.name}' ({s.id}): ยังไม่ได้เลือกฮีโร่หรือหมวดหมู่ที่มีอยู่จริง")
            continue
        skins.append(s)
        s.hero.skins.append(s)
        s.category.skins.append(s)

    packs = []
    for d in read_folder("packs"):
        items = [Obj(label=(i.get("label") if isinstance(i, dict) else str(i)))
                 for i in (d.get("items") or []) if i]
        p = Obj(id=d["id"], name=text(d, "name"), image_url=text(d, "image_url"),
                download_url=text(d, "download_url"), description=text(d, "description"),
                is_active=flag(d, "is_active"), sort_order=num(d, "sort_order"),
                items=items, category=cats.get(text(d, "category")))
        if not p.category:
            print(f"⚠️  ข้ามแพ็ค '{p.name}' ({p.id}): ยังไม่ได้เลือกหมวดหมู่ที่มีอยู่จริง")
            continue
        packs.append(p)
        p.category.packs.append(p)

    announcements = [Obj(id=d["id"], title=text(d, "title"), content=text(d, "content"),
                         is_active=flag(d, "is_active"), created_at=text(d, "created_at"))
                     for d in read_folder("announcements")]
    videos = [Obj(id=d["id"], title=text(d, "title"), video_url=text(d, "video_url"),
                  is_active=flag(d, "is_active"), sort_order=num(d, "sort_order"))
              for d in read_folder("videos")]
    backgrounds = [Obj(id=d["id"], name=text(d, "name"), image_url=text(d, "image_url"),
                       is_active=flag(d, "is_active", False))
                   for d in read_folder("backgrounds")]
    menu_links = [Obj(id=d["id"], name=text(d, "name"), icon=text(d, "icon", "fa-solid fa-link"),
                      url=text(d, "url"), open_new_tab=flag(d, "open_new_tab", False),
                      is_active=flag(d, "is_active"), sort_order=num(d, "sort_order"))
                  for d in read_folder("menu_links")]
    social_links = [Obj(id=d["id"], name=text(d, "name"), icon=text(d, "icon"), url=text(d, "url"),
                        color=text(d, "color", "#ffffff"), is_active=flag(d, "is_active"),
                        sort_order=num(d, "sort_order"))
                    for d in read_folder("social_links")]

    def active_sorted(items):
        return sorted([i for i in items if i.is_active], key=lambda i: i.sort_order)

    ann = sorted([a for a in announcements if a.is_active], key=lambda a: a.created_at, reverse=True)
    bg = next((b for b in backgrounds if b.is_active and b.image_url), None)

    return SimpleNamespace(
        heroes=list(heroes.values()),
        categories=active_sorted(cats.values()),
        skins=skins,
        packs=packs,
        announcement=ann[0] if ann else None,
        videos=active_sorted(videos),
        background=bg,
        menu_links=active_sorted(menu_links),
        social_links=active_sorted(social_links),
    )


# ---------------------------------------------------------------- Jinja
URLS = {
    "public.index": lambda **k: "/",
    "public.search": lambda **k: "/search",
    "public.heroes_page": lambda **k: "/heroes",
    "public.category_view": lambda category_id, **k: f"/category/{quote(str(category_id))}",
    "public.hero_detail": lambda hero_id, **k: f"/hero/{quote(str(hero_id))}",
    "public.skin_detail": lambda skin_id, **k: f"/skin/{quote(str(skin_id))}",
    "public.pack_detail": lambda pack_id, **k: f"/pack/{quote(str(pack_id))}",
}


def url_for(endpoint, **values):
    if endpoint == "static":
        return "/static/" + values["filename"]
    return URLS[endpoint](**values)


def make_env():
    env = Environment(
        loader=FileSystemLoader(os.path.join(BASE_DIR, "templates")),
        autoescape=select_autoescape(["html"]),
    )
    env.globals.update(
        url_for=url_for,
        get_flashed_messages=lambda **k: [],
        request=SimpleNamespace(args={}),
    )
    return env


# ---------------------------------------------------------------- สร้างไฟล์
def write(rel_path, content):
    full = os.path.join(DIST, rel_path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w", encoding="utf-8") as f:
        f.write(content)


def skin_sort(items):
    return sorted(items, key=lambda s: s.sort_order or 0)


def build():
    d = load_data()
    env = make_env()

    def render(template, rel_path, **ctx):
        html = env.get_template(template).render(
            background=d.background, social_links=d.social_links, menu_links=d.menu_links, **ctx
        )
        write(rel_path, html)

    if os.path.isdir(DIST):
        shutil.rmtree(DIST)
    os.makedirs(DIST)

    # ไฟล์ static (css, js, รูปที่อัปโหลด)
    shutil.copytree(os.path.join(BASE_DIR, "static"), os.path.join(DIST, "static"),
                    ignore=shutil.ignore_patterns(".gitkeep"))

    # หน้าแอดมิน (Decap CMS)
    shutil.copytree(os.path.join(BASE_DIR, "admin"), os.path.join(DIST, "admin"))

    # ---- หน้าแรก
    category_data = []
    for cat in d.categories:
        if cat.kind == "single":
            category_data.append({"category": cat, "type": "single",
                                  "entries": skin_sort([s for s in cat.skins if s.is_visible()])})
        elif cat.kind == "multi":
            groups = {}
            for s in cat.skins:
                if s.is_visible() and s.hero and s.hero.is_active:
                    groups.setdefault(s.hero.id, {"hero": s.hero, "skins": []})["skins"].append(s)
            hero_groups = sorted(groups.values(), key=lambda g: g["hero"].name)
            for g in hero_groups:
                g["skins"] = skin_sort(g["skins"])
            category_data.append({"category": cat, "type": "multi", "entries": hero_groups})
        elif cat.kind == "pack":
            category_data.append({"category": cat, "type": "pack",
                                  "entries": skin_sort([p for p in cat.packs if p.is_visible()])})
    render("index.html", "index.html", announcement=d.announcement, videos=d.videos,
           category_data=category_data)

    # ---- หน้าหมวดหมู่ (ค้นหาในหมวดทำฝั่งเบราว์เซอร์)
    for entry in category_data:
        cat = entry["category"]
        if cat.kind == "single":
            render("category.html", f"category/{cat.id}/index.html", category=cat, single_items=entry["entries"])
        elif cat.kind == "multi":
            render("category.html", f"category/{cat.id}/index.html", category=cat, hero_groups=entry["entries"])
        else:
            render("category.html", f"category/{cat.id}/index.html", category=cat, pack_items=entry["entries"])

    # ---- ฮีโร่
    visible_heroes = sorted(
        [h for h in d.heroes if h.is_active and any(s.is_visible() for s in h.skins)],
        key=lambda h: h.name,
    )
    render("heroes.html", "heroes/index.html", heroes=visible_heroes)
    for h in visible_heroes:
        skins = skin_sort([s for s in h.skins if s.is_visible()])
        render("hero_detail.html", f"hero/{h.id}/index.html", hero=h, skins=skins)

    # popup เลือกสกิน (ไฟล์ json ต่อฮีโร่ที่เปิดใช้งาน)
    for h in d.heroes:
        if not h.is_active:
            continue
        skins = skin_sort([s for s in h.skins if s.is_visible()])
        write(f"api/hero/{h.id}/skins.json", json.dumps({
            "hero_name": h.name,
            "skins": [{"id": s.id, "name": s.name, "image_url": s.image_url,
                       "detail_url": f"/skin/{quote(str(s.id))}"} for s in skins],
        }, ensure_ascii=False))

    # ---- รายละเอียดสกิน / แพ็ค
    for s in d.skins:
        if s.is_visible():
            render("detail.html", f"skin/{s.id}/index.html", item=s, item_type="skin")
    for p in d.packs:
        if p.is_visible():
            render("detail.html", f"pack/{p.id}/index.html", item=p, item_type="pack")

    # ---- ค้นหา (ฝั่งเบราว์เซอร์ + search-data.json)
    render("search_static.html", "search/index.html")
    write("search-data.json", json.dumps({
        "heroes": [{"id": h.id, "name": h.name, "image_url": h.image_url,
                    "skin_count": sum(1 for s in h.skins if s.is_visible())} for h in visible_heroes],
        "skins": [{"id": s.id, "name": s.name, "hero": s.hero.name if s.hero else "",
                   "image_url": s.image_url} for s in d.skins if s.is_visible()],
    }, ensure_ascii=False))

    # ---- หน้า 404 (Netlify ใช้ไฟล์นี้อัตโนมัติ)
    notfound = env.from_string(
        '{% extends "base.html" %}{% block title %}ไม่พบหน้านี้ - Rov|ModSkin{% endblock %}'
        '{% block content %}<div class="text-center py-5"><h1>404</h1>'
        '<p class="text-muted">ไม่พบหน้าที่คุณต้องการ</p>'
        '<a href="/" class="btn btn-outline-light">กลับหน้าแรก</a></div>{% endblock %}'
    )
    write("404.html", notfound.render(
        background=d.background, social_links=d.social_links, menu_links=d.menu_links))

    pages = sum(1 for _, _, fs in os.walk(DIST) for f in fs if f.endswith(".html"))
    print(f"✅ สร้างเว็บ static สำเร็จ -> {DIST}  ({pages} หน้า HTML)")
    print("   อัปโหลดโฟลเดอร์ dist/ ขึ้น Netlify ได้เลย")


if __name__ == "__main__":
    build()
