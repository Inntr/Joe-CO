#!/usr/bin/env python3
"""
ย้ายข้อมูลเดิมจาก instance/mlbb.db ไปเป็นไฟล์ JSON ในโฟลเดอร์ content/
(ใช้ครั้งเดียวตอนย้ายมาใช้ระบบแอดมินแบบ Decap CMS — ไม่ต้องรันซ้ำ)

    python export_content.py
"""
import json
import os
import shutil
import sqlite3

BASE = os.path.abspath(os.path.dirname(__file__))
DB = os.path.join(BASE, "instance", "mlbb.db")
OUT = os.path.join(BASE, "content")


def iso(v):
    if not v:
        return "2026-01-01T00:00:00.000Z"
    return str(v).replace(" ", "T")[:19] + ".000Z"


def rows(conn, table):
    try:
        return [dict(r) for r in conn.execute(f"SELECT * FROM {table} ORDER BY id")]
    except sqlite3.OperationalError:
        return []


def save(folder, prefix, rid, data):
    d = os.path.join(OUT, folder)
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, f"{prefix}-{rid}.json"), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")


def main():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    if os.path.isdir(OUT):
        shutil.rmtree(OUT)

    for r in rows(conn, "category"):
        save("categories", "category", r["id"], {
            "name": r["name"], "kind": r["kind"], "description": r["description"] or "",
            "is_active": bool(r["is_active"]), "sort_order": r["sort_order"] or 0})
    for r in rows(conn, "hero"):
        save("heroes", "hero", r["id"], {
            "name": r["name"], "image_url": r["image_url"] or "", "is_active": bool(r["is_active"])})
    for r in rows(conn, "skin"):
        save("skins", "skin", r["id"], {
            "hero": f"hero-{r['hero_id']}", "category": f"category-{r['category_id']}",
            "name": r["name"], "image_url": r["image_url"] or "", "download_url": r["download_url"] or "",
            "description": r["description"] or "", "is_active": bool(r["is_active"]),
            "sort_order": r["sort_order"] or 0})
    items = {}
    for r in rows(conn, "pack_item"):
        items.setdefault(r["pack_id"], []).append(r["label"])
    for r in rows(conn, "pack"):
        save("packs", "pack", r["id"], {
            "category": f"category-{r['category_id']}", "name": r["name"],
            "image_url": r["image_url"] or "", "download_url": r["download_url"] or "",
            "description": r["description"] or "", "is_active": bool(r["is_active"]),
            "sort_order": r["sort_order"] or 0, "items": items.get(r["id"], [])})
    for r in rows(conn, "announcement"):
        save("announcements", "announcement", r["id"], {
            "title": r["title"], "content": r["content"] or "",
            "is_active": bool(r["is_active"]), "created_at": iso(r["created_at"])})
    for r in rows(conn, "video_clip"):
        save("videos", "video", r["id"], {
            "title": r["title"] or "", "video_url": r["video_url"],
            "is_active": bool(r["is_active"]), "sort_order": r["sort_order"] or 0})
    for r in rows(conn, "background"):
        save("backgrounds", "background", r["id"], {
            "name": r["name"] or "", "image_url": r["image_url"], "is_active": bool(r["is_active"])})
    for r in rows(conn, "menu_link"):
        save("menu_links", "menu", r["id"], {
            "name": r["name"], "icon": r["icon"] or "fa-solid fa-link", "url": r["url"],
            "open_new_tab": bool(r["open_new_tab"]), "is_active": bool(r["is_active"]),
            "sort_order": r["sort_order"] or 0})
    for r in rows(conn, "social_link"):
        save("social_links", "social", r["id"], {
            "name": r["name"], "icon": r["icon"], "url": r["url"], "color": r["color"] or "#ffffff",
            "is_active": bool(r["is_active"]), "sort_order": r["sort_order"] or 0})
    conn.close()
    n = sum(len(fs) for _, _, fs in os.walk(OUT))
    print(f"✅ ย้ายข้อมูลแล้ว {n} ไฟล์ -> {OUT}")


if __name__ == "__main__":
    main()
