import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    # กุญแจลับสำหรับเข้ารหัส session ของ Flask (ควรเปลี่ยนเป็นค่าใหม่เมื่อใช้งานจริง)
    SECRET_KEY = os.environ.get("SECRET_KEY", "change-this-secret-key-in-production")

    # เชื่อมต่อฐานข้อมูล SQLite เก็บไฟล์ไว้ในโฟลเดอร์ instance/
    SQLALCHEMY_DATABASE_URI = "sqlite:///" + os.path.join(BASE_DIR, "instance", "mlbb.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # ชื่อผู้ดูแลระบบเริ่มต้น (ใช้ตอนสร้างฐานข้อมูลครั้งแรกเท่านั้น)
    DEFAULT_ADMIN_USERNAME = "admin"
    DEFAULT_ADMIN_PASSWORD = "admin1234"

    # โฟลเดอร์เก็บรูปภาพที่อัปโหลดจากเครื่อง (อยู่ใต้ static เพื่อให้ Flask เสิร์ฟไฟล์ได้เลย)
    UPLOAD_FOLDER = os.path.join(BASE_DIR, "static", "uploads")
    ALLOWED_IMAGE_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}

    # จำกัดขนาดไฟล์ที่อัปโหลดได้สูงสุด 8 MB ต่อไฟล์
    MAX_CONTENT_LENGTH = 8 * 1024 * 1024
