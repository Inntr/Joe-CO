from datetime import datetime
from extensions import db


class Admin(db.Model):
    """ตารางเก็บบัญชีผู้ดูแลระบบ"""
    __tablename__ = "admin"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Category(db.Model):
    """ตารางหมวดหมู่ มี 3 ประเภทหลัก: single (ตัวเดียว), multi (หลายสกิน), pack (แพ็ครวม)"""
    __tablename__ = "category"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    kind = db.Column(db.String(20), nullable=False)  # 'single' | 'multi' | 'pack'
    description = db.Column(db.String(255))
    is_active = db.Column(db.Boolean, default=True)
    sort_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    skins = db.relationship("Skin", backref="category", lazy=True, cascade="all, delete-orphan")
    packs = db.relationship("Pack", backref="category", lazy=True, cascade="all, delete-orphan")


class Hero(db.Model):
    """ตารางฮีโร่ ใช้จัดกลุ่มสกินและใช้ค้นหา"""
    __tablename__ = "hero"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    image_url = db.Column(db.String(500))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    skins = db.relationship("Skin", backref="hero", lazy=True, cascade="all, delete-orphan")


class Skin(db.Model):
    """ตารางสกิน ใช้ได้ทั้งหมวดตัวเดียวและหมวดหลายสกิน (แยกด้วย category.kind)"""
    __tablename__ = "skin"

    id = db.Column(db.Integer, primary_key=True)
    hero_id = db.Column(db.Integer, db.ForeignKey("hero.id"), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey("category.id"), nullable=False)

    name = db.Column(db.String(150), nullable=False)
    image_url = db.Column(db.String(500))
    download_url = db.Column(db.String(500))
    description = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    sort_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def is_visible(self):
        """แสดงผลได้ก็ต่อเมื่อเปิดใช้งานและมีลิงก์ดาวน์โหลด"""
        return bool(self.is_active and self.download_url and self.download_url.strip())


class Pack(db.Model):
    """ตารางแพ็ครวมสกิน"""
    __tablename__ = "pack"

    id = db.Column(db.Integer, primary_key=True)
    category_id = db.Column(db.Integer, db.ForeignKey("category.id"), nullable=False)

    name = db.Column(db.String(150), nullable=False)
    image_url = db.Column(db.String(500))
    download_url = db.Column(db.String(500))
    description = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    sort_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    items = db.relationship("PackItem", backref="pack", lazy=True, cascade="all, delete-orphan")

    def is_visible(self):
        return bool(self.is_active and self.download_url and self.download_url.strip())


class PackItem(db.Model):
    """รายการสกินที่รวมอยู่ในแพ็ค (ใช้แสดงรายชื่อสกินในแพ็คเท่านั้น ไม่ใช่ไฟล์แยก)"""
    __tablename__ = "pack_item"

    id = db.Column(db.Integer, primary_key=True)
    pack_id = db.Column(db.Integer, db.ForeignKey("pack.id"), nullable=False)
    label = db.Column(db.String(150), nullable=False)  # ชื่อสกิน/ฮีโร่ที่แสดงในรายการ


class Announcement(db.Model):
    """ตารางประกาศใหญ่หน้าแรก"""
    __tablename__ = "announcement"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class VideoClip(db.Model):
    """ตารางคลิปวิดีโอที่แสดงใต้ประกาศ (รองรับลิงก์ embed เช่น YouTube)"""
    __tablename__ = "video_clip"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200))
    video_url = db.Column(db.String(500), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    sort_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Background(db.Model):
    """ตารางพื้นหลังเว็บไซต์ มีได้หลายรายการแต่ใช้งานได้ทีละ 1 (is_active)"""
    __tablename__ = "background"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150))
    image_url = db.Column(db.String(500), nullable=False)
    is_active = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class MenuLink(db.Model):
    """ลิงก์นำทางในเมนูหลัก (แก้ไขได้จาก admin)"""
    __tablename__ = "menu_link"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)       # ชื่อที่แสดง
    icon = db.Column(db.String(100), default="fa-solid fa-link")  # Font Awesome class
    url = db.Column(db.String(500), nullable=False)        # URL ปลายทาง
    open_new_tab = db.Column(db.Boolean, default=False)    # เปิดในแท็บใหม่
    is_active = db.Column(db.Boolean, default=True)
    sort_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class SocialLink(db.Model):
    """ลิงก์โซเชียลมีเดีย แสดงในเมนูหน้าเว็บ"""
    __tablename__ = "social_link"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)      # ชื่อ เช่น YouTube, Discord
    icon = db.Column(db.String(100), nullable=False)      # Font Awesome class เช่น fa-brands fa-youtube
    url = db.Column(db.String(500), nullable=False)       # URL ปลายทาง
    color = db.Column(db.String(20), default="#ffffff")   # สีไอคอน
    is_active = db.Column(db.Boolean, default=True)
    sort_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
