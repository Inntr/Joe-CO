import os
from flask import Flask
from werkzeug.security import generate_password_hash

from config import Config
from extensions import db
from models import Admin, Category, SocialLink, MenuLink


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    instance_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), "instance")
    os.makedirs(instance_path, exist_ok=True)
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    db.init_app(app)

    from routes.public import public_bp
    from routes.auth import auth_bp
    from routes.admin import admin_bp

    app.register_blueprint(public_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp)

    # ส่ง social_links ให้ทุก template ใช้ได้เลย
    @app.context_processor
    def inject_globals():
        links = SocialLink.query.filter_by(is_active=True).order_by(SocialLink.sort_order.asc()).all()
        nav   = MenuLink.query.filter_by(is_active=True).order_by(MenuLink.sort_order.asc()).all()
        return dict(social_links=links, menu_links=nav)

    with app.app_context():
        db.create_all()
        seed_default_data(app)

    return app


def seed_default_data(app):
    """สร้างข้อมูลเริ่มต้น: บัญชีแอดมิน และหมวดหมู่ 3 ประเภทหลัก (ถ้ายังไม่มี)"""
    # สร้างบัญชีแอดมินเริ่มต้น
    if Admin.query.count() == 0:
        default_admin = Admin(
            username=app.config["DEFAULT_ADMIN_USERNAME"],
            password_hash=generate_password_hash(app.config["DEFAULT_ADMIN_PASSWORD"]),
        )
        db.session.add(default_admin)
        print("=" * 60)
        print(f"สร้างบัญชีแอดมินเริ่มต้นแล้ว")
        print(f"Username: {app.config['DEFAULT_ADMIN_USERNAME']}")
        print(f"Password: {app.config['DEFAULT_ADMIN_PASSWORD']}")
        print("กรุณาเปลี่ยนรหัสผ่านทันทีหลังเข้าสู่ระบบครั้งแรก")
        print("=" * 60)

    # สร้างหมวดหมู่เริ่มต้น 3 ประเภท ถ้ายังไม่มีเลยสักหมวด
    if Category.query.count() == 0:
        default_categories = [
            Category(name="ตัวเดียว", kind="single", description="สกินเดี่ยวสำหรับฮีโร่แต่ละตัว", sort_order=1),
            Category(name="หลายสกิน", kind="multi", description="ฮีโร่ที่มีสกินให้เลือกหลายแบบ", sort_order=2),
            Category(name="แพ็ครวม", kind="pack", description="แพ็คที่รวมหลายสกินไว้ในชุดเดียว", sort_order=3),
        ]
        db.session.add_all(default_categories)

    db.session.commit()


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
