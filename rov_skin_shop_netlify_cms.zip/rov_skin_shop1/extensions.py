from flask_sqlalchemy import SQLAlchemy

# สร้าง instance ของ SQLAlchemy ไว้ใช้ร่วมกันทั้งโปรเจกต์
db = SQLAlchemy()
